create
    definer = root@localhost procedure PROC_DELETEMARK(IN studentId int, OUT deletedCount int)
BEGIN
    DECLARE count INT;
    SET count = 0;
    DELETE FROM MARK
    WHERE studentId = studentId;
    SET count = ROW_COUNT();
    SET deletedCount = count;

END;

